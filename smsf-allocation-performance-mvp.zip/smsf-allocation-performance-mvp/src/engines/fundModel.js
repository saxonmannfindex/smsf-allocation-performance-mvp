/**
 * Fund Model
 * 
 * Normalizes parsed report data into a unified fund structure.
 * Combines data from multiple report types (asset allocation + performance)
 * into a single coherent model.
 */

import { analyzeFund } from '../engines/performanceEngine.js';

/**
 * Create a new fund model from parsed reports
 * 
 * @param {string} fundId - Unique identifier for the fund
 * @param {Object} options - Parsed report data
 * @param {Object} options.assetAllocation - Parsed asset allocation report
 * @param {Object} options.performance - Parsed performance report
 * @returns {Object} Normalized fund model
 */
export function createFundModel(fundId, { assetAllocation, performance }) {
  // Run analysis on the combined data
  const analysis = analyzeFund(assetAllocation, performance);
  
  // Build the normalized model
  const fund = {
    fundId,
    lastUpdated: new Date().toISOString(),
    
    // Asset Allocation data (if available)
    assetAllocation: assetAllocation ? {
      asAtDate: assetAllocation.asAtDate,
      totalValue: assetAllocation.totalValue,
      assetClasses: assetAllocation.assetClasses,
      holdings: assetAllocation.holdings,
      holdingsCount: assetAllocation.holdingsCount,
    } : null,
    
    // Performance data (if available)
    performance: performance ? {
      period: performance.period,
      startingValue: performance.startingMarketValue,
      endingValue: performance.endingMarketValue,
      dollarReturn: performance.dollarReturnAfterExpenses,
      twr: performance.twr,
    } : null,
    
    // Classification and analysis
    classification: analysis.classification,
    
    // Benchmark comparison
    benchmark: analysis.benchmark,
    benchmarkComparison: analysis.benchmarkComparison,
    
    // Performance score (0-100)
    performanceScore: analysis.performanceScore,
    
    // Derived insights
    derivedInsights: analysis.insights,
  };
  
  return fund;
}

/**
 * Generate a unique fund ID from report data
 * Uses a combination of date and hash of content
 */
export function generateFundId(reports) {
  const timestamp = Date.now();
  const contentHash = hashContent(JSON.stringify(reports));
  return `FUND-${timestamp}-${contentHash}`;
}

/**
 * Simple hash function for content-based ID generation
 */
function hashContent(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  return Math.abs(hash).toString(16).substring(0, 8);
}

/**
 * Validate that a fund model has minimum required data
 */
export function validateFundModel(fund) {
  const errors = [];
  const warnings = [];
  
  if (!fund.assetAllocation && !fund.performance) {
    errors.push('Fund must have at least one report type parsed');
  }
  
  if (!fund.classification || fund.classification.classification === 'unknown') {
    if (!fund.assetAllocation) {
      warnings.push('Cannot classify fund without asset allocation data');
    } else {
      warnings.push('Fund classification could not be determined');
    }
  }
  
  if (fund.performance && !fund.benchmarkComparison) {
    warnings.push('Benchmark comparison not available');
  }
  
  return {
    valid: errors.length === 0,
    errors,
    warnings,
    hasAssetAllocation: !!fund.assetAllocation,
    hasPerformance: !!fund.performance,
    isComplete: !!fund.assetAllocation && !!fund.performance,
  };
}

/**
 * Merge new report data into an existing fund model
 */
export function updateFundModel(existingFund, newReportType, newReportData) {
  const updates = { ...existingFund };
  
  if (newReportType === 'asset_allocation') {
    updates.assetAllocation = {
      asAtDate: newReportData.asAtDate,
      totalValue: newReportData.totalValue,
      assetClasses: newReportData.assetClasses,
      holdings: newReportData.holdings,
      holdingsCount: newReportData.holdingsCount,
    };
  } else if (newReportType === 'performance') {
    updates.performance = {
      period: newReportData.period,
      startingValue: newReportData.startingMarketValue,
      endingValue: newReportData.endingMarketValue,
      dollarReturn: newReportData.dollarReturnAfterExpenses,
      twr: newReportData.twr,
    };
  }
  
  // Re-run analysis with updated data
  const analysis = analyzeFund(updates.assetAllocation, updates.performance);
  
  updates.lastUpdated = new Date().toISOString();
  updates.classification = analysis.classification;
  updates.benchmark = analysis.benchmark;
  updates.benchmarkComparison = analysis.benchmarkComparison;
  updates.performanceScore = analysis.performanceScore;
  updates.derivedInsights = analysis.insights;
  
  return updates;
}

/**
 * Get summary statistics for display
 */
export function getFundSummary(fund) {
  return {
    totalValue: fund.assetAllocation?.totalValue || fund.performance?.endingValue || null,
    classification: fund.classification?.classification || 'unknown',
    growthPercent: fund.classification?.growthPercent || 0,
    defensivePercent: fund.classification?.defensivePercent || 0,
    oneYearReturn: fund.performance?.twr?.oneYear || null,
    dollarReturn: fund.performance?.dollarReturn || null,
    performanceScore: fund.performanceScore,
    benchmarkName: fund.benchmark?.name || null,
    holdingsCount: fund.assetAllocation?.holdingsCount || 0,
    hasAllData: !!fund.assetAllocation && !!fund.performance,
  };
}