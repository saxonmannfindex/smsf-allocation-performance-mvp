/**
 * Performance Analysis Engine
 * 
 * Analyzes fund performance metrics including:
 * - Comparison to benchmarks
 * - Risk classification
 * - Performance scoring
 */

import { 
  BENCHMARKS, 
  PERFORMANCE_THRESHOLDS,
  CLASSIFICATION_THRESHOLDS,
  GROWTH_ASSET_CLASSES,
  DEFENSIVE_ASSET_CLASSES,
} from '../utils/constants.js';

/**
 * Classify a fund based on its asset allocation
 * 
 * @param {Array} assetClasses - Array of asset class objects with name and percent
 * @returns {{classification: string, growthPercent: number, defensivePercent: number}}
 */
export function classifyFund(assetClasses) {
  if (!assetClasses || assetClasses.length === 0) {
    if (!assetClasses || assetClasses.length === 0) {
    return {
      classification: 'unknown',
      growthPercent: 0,
      defensivePercent: 0,
      otherPercent: 0,
    };
  }

  const totalValue = assetClasses.reduce(
    (sum, ac) => sum + (ac.value || 0),
    0
  );

  const growthValue = assetClasses
    .filter(ac => GROWTH_ASSET_CLASSES.includes(ac.name))
    .reduce((sum, ac) => sum + (ac.value || 0), 0);

  const defensiveValue = assetClasses
    .filter(ac => DEFENSIVE_ASSET_CLASSES.includes(ac.name))
    .reduce((sum, ac) => sum + (ac.value || 0), 0);

  const growthPercent = totalValue > 0 ? (growthValue / totalValue) * 100 : 0;
  const defensivePercent = totalValue > 0 ? (defensiveValue / totalValue) * 100 : 0;
  const otherPercent = 100 - growthPercent - defensivePercent;

  let classification;
  if (growthPercent < CLASSIFICATION_THRESHOLDS.DEFENSIVE_MAX) {
    classification = 'defensive';
  } else if (growthPercent > CLASSIFICATION_THRESHOLDS.GROWTH_MIN) {
    classification = 'growth';
  } else {
    classification = 'balanced';
  }

  return {
    classification,
    growthPercent,
    defensivePercent,
    otherPercent,
  };
}
  // Calculate growth asset percentage
  const growthPercent = assetClasses
    .filter(ac => GROWTH_ASSET_CLASSES.includes(ac.name))
    .reduce((sum, ac) => sum + (ac.percent || 0), 0);
  
  // Calculate defensive asset percentage
  const defensivePercent = assetClasses
    .filter(ac => DEFENSIVE_ASSET_CLASSES.includes(ac.name))
    .reduce((sum, ac) => sum + (ac.percent || 0), 0);
  
  // Calculate other (unclassified) percentage
  const otherPercent = 100 - growthPercent - defensivePercent;
  
  // Determine classification
  let classification;
  if (growthPercent < CLASSIFICATION_THRESHOLDS.DEFENSIVE_MAX) {
    classification = 'defensive';
  } else if (growthPercent > CLASSIFICATION_THRESHOLDS.GROWTH_MIN) {
    classification = 'growth';
  } else {
    classification = 'balanced';
  }
  
  return {
    classification,
    growthPercent,
    defensivePercent,
    otherPercent,
  };
}

/**
 * Get the appropriate benchmark for a fund classification
 * 
 * @param {string} classification - Fund classification (defensive/balanced/growth)
 * @returns {Object} Benchmark data
 */
export function getBenchmark(classification) {
  return BENCHMARKS[classification] || BENCHMARKS.balanced;
}

/**
 * Compare fund performance to its benchmark
 * 
 * @param {Object} fundPerformance - Fund's TWR values
 * @param {Object} benchmark - Benchmark data
 * @returns {Object} Comparison results
 */
export function compareToBenchmark(fundPerformance, benchmark) {
  const comparisons = {
    oneYear: null,
    threeYears: null,
    sinceInception: null,
  };
  
  if (fundPerformance.oneYear !== null && benchmark.returns.oneYear) {
    const diff = fundPerformance.oneYear - benchmark.returns.oneYear;
    comparisons.oneYear = {
      fundReturn: fundPerformance.oneYear,
      benchmarkReturn: benchmark.returns.oneYear,
      difference: diff,
      status: getPerformanceStatus(diff),
    };
  }
  
  if (fundPerformance.threeYears !== null && benchmark.returns.threeYears) {
    const diff = fundPerformance.threeYears - benchmark.returns.threeYears;
    comparisons.threeYears = {
      fundReturn: fundPerformance.threeYears,
      benchmarkReturn: benchmark.returns.threeYears,
      difference: diff,
      status: getPerformanceStatus(diff),
    };
  }
  
  // Use sinceStart as "since inception" proxy
  if (fundPerformance.sinceStart !== null && benchmark.returns.sinceInception) {
    const diff = fundPerformance.sinceStart - benchmark.returns.sinceInception;
    comparisons.sinceInception = {
      fundReturn: fundPerformance.sinceStart,
      benchmarkReturn: benchmark.returns.sinceInception,
      difference: diff,
      status: getPerformanceStatus(diff),
    };
  }
  
  return comparisons;
}

/**
 * Determine performance status based on difference from benchmark
 */
function getPerformanceStatus(difference) {
  if (difference >= PERFORMANCE_THRESHOLDS.STRONG_OUTPERFORMANCE) {
    return 'strong_outperformance';
  } else if (difference >= PERFORMANCE_THRESHOLDS.SLIGHT_OUTPERFORMANCE) {
    return 'slight_outperformance';
  } else if (difference >= PERFORMANCE_THRESHOLDS.SLIGHT_UNDERPERFORMANCE) {
    return 'inline';
  } else if (difference >= PERFORMANCE_THRESHOLDS.STRONG_UNDERPERFORMANCE) {
    return 'slight_underperformance';
  } else {
    return 'strong_underperformance';
  }
}

/**
 * Analyze complete fund data including allocation and performance
 * 
 * @param {Object} assetAllocation - Parsed asset allocation data
 * @param {Object} performance - Parsed performance data
 * @returns {Object} Complete analysis results
 */
export function analyzeFund(assetAllocation, performance) {
  // Classify the fund based on asset allocation
 
  const classification = assetAllocation?.classification || {
  classification: 'unknown',
  growthPercent: 0,
  defensivePercent: 0,
};

  
  // Get appropriate benchmark
  const benchmark = getBenchmark(classification.classification);
  
  // Compare performance to benchmark
 const benchmarkComparison = performance?.twr
  ? compareToBenchmark(
      {
        oneYear: performance.twr.oneYear ?? null,
        threeYears: performance.twr.threeYears ?? null,
        sinceStart: performance.twr.sinceStart ?? null,
      },
      benchmark
    )
  : null;

  // Calculate overall performance score (0-100)
  const performanceScore = calculatePerformanceScore(
    performance,
    benchmarkComparison,
    classification.classification
  );
  
  // Generate insights
  const insights = generateInsights(
    assetAllocation,
    performance,
    classification,
    benchmarkComparison
  );
  
  return {
    classification,
    benchmark: {
      name: benchmark.name,
      description: benchmark.description,
      composition: benchmark.composition,
      riskLevel: benchmark.riskLevel,
    },
    benchmarkComparison,
    performanceScore,
    insights,
  };
}

/**
 * Calculate an overall performance score
 */
function calculatePerformanceScore(performance, comparison, classification) {
  if (!performance || !comparison) return null;
  
  let score = 50; // Start at neutral
  
  // Adjust for 1-year performance vs benchmark
  if (comparison.oneYear) {
    const diff = comparison.oneYear.difference;
    score += Math.min(Math.max(diff * 5, -25), 25); // -25 to +25 adjustment
  }
  
  // Adjust for absolute return
  if (performance.twr?.oneYear !== null) {
    const absReturn = performance.twr.oneYear;
    if (absReturn >= PERFORMANCE_THRESHOLDS.EXCELLENT_RETURN) {
      score += 15;
    } else if (absReturn >= PERFORMANCE_THRESHOLDS.GOOD_RETURN) {
      score += 10;
    } else if (absReturn >= PERFORMANCE_THRESHOLDS.MODERATE_RETURN) {
      score += 5;
    } else if (absReturn < PERFORMANCE_THRESHOLDS.POOR_RETURN) {
      score -= 10;
    }
  }
  
  // Cap at 0-100
  return Math.min(Math.max(Math.round(score), 0), 100);
}

/**
 * Generate human-readable insights about the fund
 */
function generateInsights(assetAllocation, performance, classification, comparison) {
  const insights = [];
  
  // Classification insight
  if (classification.classification !== 'unknown') {
    const classLabel = classification.classification.charAt(0).toUpperCase() + 
                       classification.classification.slice(1);
    insights.push({
      type: 'classification',
      title: `${classLabel} Investment Profile`,
      description: `With ${classification.growthPercent.toFixed(1)}% in growth assets, ` +
                   `this fund follows a ${classification.classification} strategy.`,
      importance: 'high',
    });
  }
  
  // Performance vs benchmark insight
  if (comparison?.oneYear) {
    const diff = comparison.oneYear.difference;
    const status = comparison.oneYear.status;
    
    let description;
    if (status.includes('outperformance')) {
      description = `The fund outperformed its benchmark by ${Math.abs(diff).toFixed(2)}% ` +
                    `over the past year.`;
    } else if (status === 'inline') {
      description = `The fund performed in line with its benchmark over the past year.`;
    } else {
      description = `The fund underperformed its benchmark by ${Math.abs(diff).toFixed(2)}% ` +
                    `over the past year.`;
    }
    
    insights.push({
      type: 'performance',
      title: 'Benchmark Comparison',
      description,
      importance: status.includes('strong') ? 'high' : 'medium',
    });
  }
  
  // Concentration insight
  if (assetAllocation?.holdings) {
    const topHoldings = assetAllocation.holdings
      .sort((a, b) => (b.value || 0) - (a.value || 0))
      .slice(0, 5);
    
    if (topHoldings.length > 0 && assetAllocation.totalValue) {
      const top5Value = topHoldings.reduce((sum, h) => sum + (h.value || 0), 0);
      const top5Percent = (top5Value / assetAllocation.totalValue) * 100;
      
      if (top5Percent > 40) {
        insights.push({
          type: 'concentration',
          title: 'Portfolio Concentration',
          description: `The top 5 holdings represent ${top5Percent.toFixed(1)}% of the portfolio. ` +
                       `Consider reviewing diversification.`,
          importance: 'medium',
        });
      }
    }
  }
  
  // Dollar return insight
  if (performance?.dollarReturnAfterExpenses) {
    const dollarReturn = performance.dollarReturnAfterExpenses;
    const isPositive = dollarReturn > 0;
    
    insights.push({
      type: 'return',
      title: 'Total Dollar Return',
      description: `The fund ${isPositive ? 'gained' : 'lost'} $${Math.abs(dollarReturn).toLocaleString()} ` +
                   `after expenses during the reporting period.`,
      importance: 'high',
    });
  }
  
  return insights;
}

/**
 * Get classification badge styling
 */
export function getClassificationStyle(classification) {
  const styles = {
    defensive: {
      bgColor: 'bg-green-100',
      textColor: 'text-green-800',
      borderColor: 'border-green-200',
      icon: '🛡️',
    },
    balanced: {
      bgColor: 'bg-amber-100',
      textColor: 'text-amber-800',
      borderColor: 'border-amber-200',
      icon: '⚖️',
    },
    growth: {
      bgColor: 'bg-red-100',
      textColor: 'text-red-800',
      borderColor: 'border-red-200',
      icon: '📈',
    },
    unknown: {
      bgColor: 'bg-gray-100',
      textColor: 'text-gray-800',
      borderColor: 'border-gray-200',
      icon: '❓',
    },
  };
  
  return styles[classification] || styles.unknown;
}