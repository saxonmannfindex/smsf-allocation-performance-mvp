export function classifyGrowthDefensive(assetClasses = []) {
  let growthValue = 0;
  let defensiveValue = 0;
  let totalValue = 0;

  for (const ac of assetClasses) {
    if (ac.value == null) continue;

    const value = Number(ac.value);
    const name = ac.name.toLowerCase();

    totalValue += value;

    // Defensive
    if (
      name.includes('cash') ||
      name.includes('fixed interest') ||
      name.includes('mortgage')
    ) {
      defensiveValue += value;
      continue;
    }

    // Growth
    if (
      name.includes('equities') ||
      name.includes('property') ||
      name.includes('international')
    ) {
      growthValue += value;
      continue;
    }

    // Unknown → conservative assumption
    growthValue += value;
  }

  if (totalValue === 0) {
    return {
      classification: 'unknown',
      growthPercent: 0,
      defensivePercent: 0,
    };
  }

  const growthPercent = (growthValue / totalValue) * 100;
  const defensivePercent = (defensiveValue / totalValue) * 100;

  let classification = 'balanced';
  if (growthPercent >= 85) classification = 'growth';
  else if (growthPercent >= 65) classification = 'balanced';
  else if (growthPercent >= 35) classification = 'conservative';
  else classification = 'defensive';

  return {
    classification,
    growthPercent,
    defensivePercent,
  };
}
