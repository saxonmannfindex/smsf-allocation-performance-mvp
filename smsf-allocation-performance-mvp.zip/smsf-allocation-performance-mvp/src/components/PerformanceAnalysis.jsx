export default function PerformanceAnalysis({ fund }) {
  if (!fund?.performance) {
    return (
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h3 className="text-lg font-semibold mb-2">Performance</h3>
        <p className="text-sm text-gray-500">
          Upload the Performance (TWR) report to view results.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold mb-4">Performance</h3>

      <div className="space-y-2 text-sm">
        <div className="flex justify-between">
          <span className="text-gray-500">Time-Weighted Return</span>
          <span className="font-medium">
            {(fund.performance.twr * 100).toFixed(2)}%
          </span>
        </div>

        {fund.benchmark && (
          <div className="flex justify-between">
            <span className="text-gray-500">Benchmark</span>
            <span className="font-medium">{fund.benchmark.name}</span>
          </div>
        )}
      </div>
    </div>
  );
}
