export default function FundSummary({ fund }) {
  if (!fund) return null;

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold mb-4">Fund Summary</h3>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div>
          <p className="text-gray-500">Fund ID</p>
          <p className="font-medium">{fund.fundId}</p>
        </div>

        <div>
          <p className="text-gray-500">Classification</p>
          <p className="font-medium capitalize">
            {fund.classification?.classification ?? "Unknown"}
          </p>
        </div>

        <div>
          <p className="text-gray-500">Growth Assets</p>
          <p className="font-medium">
            {fund.classification?.growthPercent?.toFixed(1) ?? "–"}%
          </p>
        </div>

        <div>
          <p className="text-gray-500">Defensive Assets</p>
          <p className="font-medium">
            {fund.classification?.defensivePercent?.toFixed(1) ?? "–"}%
          </p>
        </div>
      </div>
    </div>
  );
}
