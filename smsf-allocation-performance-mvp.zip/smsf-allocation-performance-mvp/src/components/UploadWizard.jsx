/**
 * UploadWizard Component
 * 
 * Two-step upload flow for PDF reports:
 * 1. Upload Asset Allocation report
 * 2. Upload Performance (TWR) report
 * 
 * Shows progress, validation, and allows re-upload at each step.
 * 
 * WHY TWO-STEP (Option A)?
 * - Clearer user experience with explicit steps
 * - Easier to validate each report type independently
 * - User can see partial results after first upload
 * - Simple to understand for users unfamiliar with the reports
 * - Avoids complex auto-detection that could misidentify reports
 */

import React, { useState, useCallback } from 'react';
import { ArrowRight, Check, RefreshCw, FileText, AlertCircle } from 'lucide-react';
import DropZone from './DropZone.jsx';
import { extractTextFromPDF } from '../utils/pdfParser.js';
import { parseReport, identifyReportType } from '../parsers/reportRegistry.js';

// Step definitions
const STEPS = [
  {
    id: 1,
    key: 'asset_allocation',
    title: 'Asset Allocation Report',
    description: 'Upload the Investment Allocation PDF',
    expectedType: 'asset_allocation',
  },
  {
    id: 2,
    key: 'performance',
    title: 'Performance Report',
    description: 'Upload the Investment Movement and Returns PDF',
    expectedType: 'performance',
  },
];

export default function UploadWizard({ onComplete, onPartialData }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [uploadStatus, setUploadStatus] = useState({
    asset_allocation: 'idle', // idle, processing, success, error
    performance: 'idle',
  });
  const [parsedData, setParsedData] = useState({
    asset_allocation: null,
    performance: null,
  });
  const [errors, setErrors] = useState({
    asset_allocation: null,
    performance: null,
  });

  // Handle file upload for a specific step
  const handleFileUpload = useCallback(async (file, error, stepKey) => {
    if (error) {
      setErrors(prev => ({ ...prev, [stepKey]: error }));
      setUploadStatus(prev => ({ ...prev, [stepKey]: 'error' }));
      return;
    }

    if (!file) return;

    setUploadStatus(prev => ({ ...prev, [stepKey]: 'processing' }));
    setErrors(prev => ({ ...prev, [stepKey]: null }));

    try {
      // Extract text from PDF
      console.log(`[UploadWizard] Extracting text from ${file.name}...`);
      const extractedPdf = await extractTextFromPDF(file);
      
      if (!extractedPdf.fullText || extractedPdf.fullText.length < 100) {
        throw new Error('Could not extract text from PDF. The file may be image-based or corrupted.');
      }

      // Identify report type
      const identification = identifyReportType(extractedPdf.fullText);
      console.log(`[UploadWizard] Identified as: ${identification?.type || 'unknown'}`);

      // Check if it matches expected type for this step
      const step = STEPS.find(s => s.key === stepKey);
      if (identification?.type !== step.expectedType) {
        const expectedName = step.title;
        const actualName = identification?.name || 'Unknown report type';
        throw new Error(
          `This appears to be a ${actualName}. Please upload a ${expectedName} for this step.`
        );
      }

      // Parse the report
      const parsed = await parseReport(extractedPdf);
      console.log(`[UploadWizard] Parsed ${stepKey}:`, parsed);

      // Update state
      const newParsedData = { ...parsedData, [stepKey]: parsed.data };
      setParsedData(newParsedData);
      setUploadStatus(prev => ({ ...prev, [stepKey]: 'success' }));

      // Notify parent of partial data
      if (onPartialData) {
        onPartialData(stepKey, parsed.data);
      }

      // Auto-advance to next step if not on last step
      if (currentStep < STEPS.length) {
        setTimeout(() => setCurrentStep(currentStep + 1), 500);
      }

      // Check if both reports are uploaded
      if (stepKey === 'performance' && newParsedData.asset_allocation) {
        // Both reports complete
        if (onComplete) {
          onComplete(newParsedData);
        }
      } else if (stepKey === 'asset_allocation' && newParsedData.performance) {
        // Both reports complete (uploaded in reverse order)
        if (onComplete) {
          onComplete(newParsedData);
        }
      }

    } catch (err) {
      console.error(`[UploadWizard] Error processing ${stepKey}:`, err);
      setErrors(prev => ({ ...prev, [stepKey]: err.message }));
      setUploadStatus(prev => ({ ...prev, [stepKey]: 'error' }));
    }
  }, [currentStep, parsedData, onComplete, onPartialData]);

  // Reset a specific step
  const handleReset = useCallback((stepKey) => {
    setParsedData(prev => ({ ...prev, [stepKey]: null }));
    setUploadStatus(prev => ({ ...prev, [stepKey]: 'idle' }));
    setErrors(prev => ({ ...prev, [stepKey]: null }));
  }, []);

  // Check if all steps are complete
  const isComplete = parsedData.asset_allocation && parsedData.performance;

  return (
    <div className="space-y-6">
      {/* Progress Indicator */}
      <div className="flex items-center justify-center gap-4">
        {STEPS.map((step, index) => (
          <React.Fragment key={step.id}>
            <StepIndicator
              step={step}
              isActive={currentStep === step.id}
              isComplete={uploadStatus[step.key] === 'success'}
              hasError={uploadStatus[step.key] === 'error'}
              onClick={() => setCurrentStep(step.id)}
            />
            {index < STEPS.length - 1 && (
              <ArrowRight className="w-5 h-5 text-gray-300" />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Step Content */}
      <div className="grid md:grid-cols-2 gap-6">
        {STEPS.map((step) => (
          <StepCard
            key={step.key}
            step={step}
            status={uploadStatus[step.key]}
            error={errors[step.key]}
            isActive={currentStep === step.id}
            parsedData={parsedData[step.key]}
            onFileUpload={(file, error) => handleFileUpload(file, error, step.key)}
            onReset={() => handleReset(step.key)}
          />
        ))}
      </div>

      {/* Completion Message */}
      {isComplete && (
        <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
          <Check className="w-8 h-8 text-green-500 mx-auto mb-2" />
          <p className="text-green-700 font-medium">Both reports uploaded successfully!</p>
          <p className="text-green-600 text-sm">Analysis is ready below.</p>
        </div>
      )}
    </div>
  );
}

/**
 * Step indicator in the progress bar
 */
function StepIndicator({ step, isActive, isComplete, hasError, onClick }) {
  let bgColor = 'bg-gray-200';
  let textColor = 'text-gray-500';
  let ringColor = '';

  if (isComplete) {
    bgColor = 'bg-green-500';
    textColor = 'text-white';
  } else if (hasError) {
    bgColor = 'bg-red-500';
    textColor = 'text-white';
  } else if (isActive) {
    bgColor = 'bg-blue-500';
    textColor = 'text-white';
    ringColor = 'ring-4 ring-blue-200';
  }

  return (
    <button
      onClick={onClick}
      className={`
        flex items-center justify-center w-10 h-10 rounded-full
        ${bgColor} ${textColor} ${ringColor}
        font-medium text-sm transition-all cursor-pointer
        hover:opacity-90
      `}
    >
      {isComplete ? <Check className="w-5 h-5" /> : step.id}
    </button>
  );
}

/**
 * Individual step card with upload zone
 */
function StepCard({ step, status, error, isActive, parsedData, onFileUpload, onReset }) {
  const isComplete = status === 'success';
  
  return (
    <div className={`
      rounded-xl border-2 transition-all duration-200
      ${isActive ? 'border-blue-300 shadow-md' : 'border-gray-200'}
      ${isComplete ? 'bg-green-50 border-green-300' : 'bg-white'}
    `}>
      {/* Card Header */}
      <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
        <div>
          <h3 className="font-medium text-gray-900">{step.title}</h3>
          <p className="text-xs text-gray-500">{step.description}</p>
        </div>
        {isComplete && (
          <button
            onClick={onReset}
            className="p-1 text-gray-400 hover:text-gray-600 rounded"
            title="Upload different file"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        )}
      </div>
      
      {/* Upload Zone */}
      <div className="p-4">
        <DropZone
          onFileSelect={onFileUpload}
          status={status}
          label={`Upload ${step.title}`}
          description="Drag and drop or click to browse"
          errorMessage={error}
          acceptedFileName={isComplete ? `${step.title} loaded` : null}
        />
        
        {/* Parsed Data Preview */}
        {isComplete && parsedData && (
          <ParsedDataPreview type={step.key} data={parsedData} />
        )}
      </div>
    </div>
  );
}

/**
 * Preview of parsed data
 */
function ParsedDataPreview({ type, data }) {
  if (type === 'asset_allocation' && data) {
    return (
      <div className="mt-3 p-3 bg-white rounded border border-gray-200 text-sm">
        <div className="flex items-center gap-2 text-green-600 mb-2">
          <FileText className="w-4 h-4" />
          <span className="font-medium">Extracted Data</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
          <div>Asset Classes: <span className="font-medium text-gray-900">{data.assetClasses?.length || 0}</span></div>
          <div>Holdings: <span className="font-medium text-gray-900">{data.holdings?.length || 0}</span></div>
          <div>Total Value: <span className="font-medium text-gray-900">${(data.totalValue || 0).toLocaleString()}</span></div>
          <div>Date: <span className="font-medium text-gray-900">{data.asAtDate || 'N/A'}</span></div>
        </div>
      </div>
    );
  }
  
  if (type === 'performance' && data) {
    return (
      <div className="mt-3 p-3 bg-white rounded border border-gray-200 text-sm">
        <div className="flex items-center gap-2 text-green-600 mb-2">
          <FileText className="w-4 h-4" />
          <span className="font-medium">Extracted Data</span>
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
          <div>Period: <span className="font-medium text-gray-900">{data.period?.from || 'N/A'} to {data.period?.to || 'N/A'}</span></div>
          <div>1Y TWR: <span className="font-medium text-gray-900">{data.twr?.oneYear != null ? `${data.twr.oneYear}%` : 'N/A'}</span></div>
          <div>Ending Value: <span className="font-medium text-gray-900">${(data.endingMarketValue || 0).toLocaleString()}</span></div>
          <div>Net Return: <span className="font-medium text-gray-900">${(data.dollarReturnAfterExpenses || 0).toLocaleString()}</span></div>
        </div>
      </div>
    );
  }
  
  return null;
}