import React from "react";
import { Upload, AlertCircle, Check } from "lucide-react";

export default function DropZone({
  onFileSelect,
  status = "idle",
  label,
  description,
  errorMessage,
  acceptedFileName
}) {
  const handleChange = (e) => {
    const file = e.target.files?.[0];
    console.log("[DropZone] File selected:", file?.name);

    if (!file) {
      onFileSelect(null, "No file selected");
      return;
    }

    onFileSelect(file, null);
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-medium text-gray-700">
        {label}
      </label>

      <input
        type="file"
        accept="application/pdf"
        onChange={handleChange}
        className="block w-full text-sm text-gray-600
          file:mr-4 file:py-2 file:px-4
          file:rounded-lg file:border-0
          file:text-sm file:font-semibold
          file:bg-blue-50 file:text-blue-700
          hover:file:bg-blue-100"
      />

      {description && (
        <p className="text-xs text-gray-500">{description}</p>
      )}

      {status === "processing" && (
        <p className="text-xs text-blue-600">Processing PDF…</p>
      )}

      {status === "success" && (
        <div className="flex items-center gap-2 text-xs text-green-600">
          <Check className="w-4 h-4" />
          {acceptedFileName || "File uploaded"}
        </div>
      )}

      {status === "error" && errorMessage && (
        <div className="flex items-center gap-2 text-xs text-red-600">
          <AlertCircle className="w-4 h-4" />
          {errorMessage}
        </div>
      )}
    </div>
  );
}
