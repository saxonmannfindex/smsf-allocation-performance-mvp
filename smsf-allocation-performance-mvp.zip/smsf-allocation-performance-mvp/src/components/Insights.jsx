export function PerformanceScoreCard({ score }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold mb-2">Performance Score</h3>
      <p className="text-3xl font-bold">{score ?? "–"}</p>
    </div>
  );
}

export default function Insights({ insights = [] }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold mb-4">Insights</h3>

      {insights.length === 0 ? (
        <p className="text-sm text-gray-500">
          No insights available yet.
        </p>
      ) : (
        <ul className="space-y-3 text-sm">
  {insights.map((insight, i) => (
    <li key={i} className="border-l-4 pl-3 border-gray-300">
      <p className="font-medium text-gray-900">
        {insight.title}
      </p>
      <p className="text-gray-600">
        {insight.description}
      </p>
    </li>
  ))}
</ul>
      )}
    </div>
  );
}
